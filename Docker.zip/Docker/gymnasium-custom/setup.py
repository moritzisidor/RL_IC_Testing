from setuptools import setup

setup(
    name="gymnasium_custom",
    version="0.0.1",
    install_requires=["gymnasium", "pygame"],
)